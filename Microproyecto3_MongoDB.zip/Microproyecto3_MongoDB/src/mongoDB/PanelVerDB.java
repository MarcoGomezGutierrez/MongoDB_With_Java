package mongoDB;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import mongoDB.panel.PanelActualizar;
import mongoDB.panel.PanelCambioInsertar;
import mongoDB.panel.PanelEliminar;
import mongoDB.panel.PanelMostrar;

public class PanelVerDB extends JPanel {

	private static final long serialVersionUID = 1260779806000738196L;
	private JPanel panel_cambios;
	private JButton btn_insertar;
	private JButton btn_mostrar;
	private JButton btn_actualizar;
	private JButton btn_eliminar;
	private JPanel panel_btns;
	private PanelCambioInsertar panel_insertar = new PanelCambioInsertar();
	private PanelActualizar panel_actualizar = new PanelActualizar();
	private PanelEliminar panel_eliminar = new PanelEliminar();
	private PanelMostrar panel_mostrar = new PanelMostrar();

	public PanelVerDB() {
		setLayout(new BorderLayout(0, 0));
		setSize(1013,618);
		
		panel_btns = new JPanel();
		add(panel_btns, BorderLayout.NORTH);
		
		btn_insertar = new JButton("Insertar");
		btn_insertar.setFont(new Font("Arial Narrow", btn_insertar.getFont().getStyle() & ~Font.ITALIC | Font.BOLD, btn_insertar.getFont().getSize() + 7));
		btn_insertar.setPreferredSize(new Dimension(150, 70));
		panel_btns.add(btn_insertar);
		
		btn_mostrar = new JButton("Mostrar");
		btn_mostrar.setFont(new Font("Arial Narrow", btn_mostrar.getFont().getStyle() & ~Font.ITALIC | Font.BOLD, btn_mostrar.getFont().getSize() + 7));
		btn_mostrar.setPreferredSize(new Dimension(150, 70));
		panel_btns.add(btn_mostrar);
		
		btn_actualizar = new JButton("Actualizar");
		btn_actualizar.setFont(new Font("Arial Narrow", btn_actualizar.getFont().getStyle() & ~Font.ITALIC | Font.BOLD, btn_actualizar.getFont().getSize() + 7));
		btn_actualizar.setPreferredSize(new Dimension(150, 70));
		panel_btns.add(btn_actualizar);
		
		btn_eliminar = new JButton("Eliminar");
		btn_eliminar.setFont(new Font("Arial Narrow", btn_eliminar.getFont().getStyle() & ~Font.ITALIC | Font.BOLD, btn_eliminar.getFont().getSize() + 7));
		btn_eliminar.setPreferredSize(new Dimension(150, 70));
		panel_btns.add(btn_eliminar);
		
		panel_cambios = new JPanel();
		add(panel_cambios, BorderLayout.CENTER);
		
		actionPerformed(btn_insertar);
		actionPerformed(btn_mostrar);
		actionPerformed(btn_actualizar);
		actionPerformed(btn_eliminar);
		
		
		panel_cambios.add(panel_insertar);
		panel_cambios.add(panel_mostrar);
		panel_cambios.add(panel_actualizar);
		panel_cambios.add(panel_eliminar);
		
		panel_insertar.setVisible(true);
		panel_mostrar.setVisible(false);
		panel_actualizar.setVisible(false);
		panel_eliminar.setVisible(false);
		btn_insertar.setEnabled(false);
		
	}
	
	private void deshabilitarBotones() {
		if (panel_insertar.isVisible()) {
			btn_insertar.setEnabled(false);
			btn_mostrar.setEnabled(true);
			btn_actualizar.setEnabled(true);
			btn_eliminar.setEnabled(true);
		}else if (panel_mostrar.isVisible()) {
			btn_insertar.setEnabled(true);
			btn_mostrar.setEnabled(false);
			btn_actualizar.setEnabled(true);
			btn_eliminar.setEnabled(true);
		}else if (panel_actualizar.isVisible()) {
			btn_insertar.setEnabled(true);
			btn_mostrar.setEnabled(true);
			btn_actualizar.setEnabled(false);
			btn_eliminar.setEnabled(true);
		}else if (panel_eliminar.isVisible()) {
			btn_insertar.setEnabled(true);
			btn_mostrar.setEnabled(true);
			btn_actualizar.setEnabled(true);
			btn_eliminar.setEnabled(false);
		}
	}
	
	private final void actionPerformed(JButton btn) {
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object evt = e.getSource();
				if (evt.equals(btn_insertar)) {
					panel_insertar.setVisible(true);
					panel_mostrar.setVisible(false);
					panel_actualizar.setVisible(false);
					panel_eliminar.setVisible(false);
					panel_cambios.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_mostrar)) {
					panel_insertar.setVisible(false);
					panel_mostrar.setVisible(true);
					panel_actualizar.setVisible(false);
					panel_eliminar.setVisible(false);
					panel_cambios.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_actualizar)) {
					panel_insertar.setVisible(false);
					panel_mostrar.setVisible(false);
					panel_actualizar.setVisible(true);
					panel_eliminar.setVisible(false);
					panel_cambios.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_eliminar)) {
					panel_insertar.setVisible(false);
					panel_mostrar.setVisible(false);
					panel_actualizar.setVisible(false);
					panel_eliminar.setVisible(true);
					panel_cambios.validate();
					deshabilitarBotones();
				}
			}
		});
	}

}
