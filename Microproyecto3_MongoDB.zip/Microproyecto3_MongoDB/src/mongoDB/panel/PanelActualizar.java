package mongoDB.panel;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Image;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import com.mongodb.DBCursor;
import mongoDB.PanelSeleccionarDB;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PanelActualizar extends JPanel {

	private static final long serialVersionUID = -8560319000558375871L;

	private JLabel lbl_imagen;
	private JTable table;
	private JScrollPane scrollPane;
	private DefaultTableModel model;
	private PanelSeleccionarDB panelSeleccionarDB = new PanelSeleccionarDB();
	private JButton btn_seleccionar;
	private JButton btn_refrescar;
	private int filas = 0;
	private static int filaSeleccionada = 0;
	private JPanel panel_1;
	private JButton btn_actualizar;
	private final ImageIcon tick = new ImageIcon("src\\Imagenes\\tick.png");
	private final ImageIcon x = new ImageIcon("src\\Imagenes\\x.png");

	public PanelActualizar() {
		setLayout(new BorderLayout(0, 0));
		setSize(1013, 618);
		
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.NORTH);
		
		lbl_imagen = new JLabel();
		lbl_imagen.setPreferredSize(new Dimension(40, 30));
		panel.add(lbl_imagen);
		
		//Botones
		btn_refrescar = new JButton("Refrescar");
		panel.add(btn_refrescar);
		
		btn_seleccionar = new JButton("Seleccionar");
		panel.add(btn_seleccionar);
		
		//Tabla
		table = new JTable(0, 1);
		table.getColumn("A").setHeaderValue("Collection");
		
		//Scroll
		scrollPane = new JScrollPane(table);
		scrollPane.setPreferredSize(new Dimension(500, 300));
		add(scrollPane, BorderLayout.CENTER);
		
		panel_1 = new JPanel();
		add(panel_1, BorderLayout.SOUTH);
		
		btn_actualizar = new JButton("Actualizar");
		btn_actualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!table.isEditing()) {
					btn_actualizar.setVisible(false);
					model = (DefaultTableModel) table.getModel();
					String resultado = (String) model.getValueAt(0, 0);
					panelSeleccionarDB.actualizar(filaSeleccionada, resultado);
					model.removeRow(0);
					filas --;
					lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
				}else {
					lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
				}
			}
		});
		btn_actualizar.setPreferredSize(new Dimension(150, 60));
		btn_actualizar.setVisible(false);
		panel_1.add(btn_actualizar);
		
		
		//Acciones botones
		btn_refrescar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lbl_imagen.setIcon(null);
				if (!table.isEditing()) {
					btn_actualizar.setVisible(false);
					btn_seleccionar.setEnabled(true);
					eliminarTabla();
					DBCursor cursor = panelSeleccionarDB.getCollection().find();
					model = (DefaultTableModel) table.getModel();
					try {
						while (cursor.hasNext()) {
							model.addRow(new Object[filas]);
							model.setValueAt(cursor.next().toString(), filas, 0);
							filas++;
						}
					} finally {
						  cursor.close(); 
					}
				}else {
					lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
				}
			}
		});
		
		btn_seleccionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lbl_imagen.setIcon(null);
				if (table.getSelectedRow()!=-1) {
					lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					filaSeleccionada = table.getSelectedRow();
					eliminarTablaMenos(filaSeleccionada);
					table.editCellAt(0, 0);
					btn_actualizar.setVisible(true);
					btn_seleccionar.setEnabled(false);
				}else {
					lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
				}
			}
		});
	}
	
	private void eliminarTabla() {
		model = (DefaultTableModel) table.getModel();
		for(int i=filas-1; i>=0; i--){
			model.removeRow(i);
			filas --;
		}
	}
	
	private void eliminarTablaMenos(int num) {
		model = (DefaultTableModel) table.getModel();
		for(int i=filas-1; i>=0; i--){
			if (i!=num) {
				model.removeRow(i);
				filas --;
			}
		}
	}
	

}
