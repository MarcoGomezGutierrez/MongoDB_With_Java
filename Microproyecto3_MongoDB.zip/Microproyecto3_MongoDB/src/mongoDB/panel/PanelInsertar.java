package mongoDB.panel;

import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Image;
import javax.swing.JTable;
import java.awt.BorderLayout;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import com.toedter.calendar.JDateChooser;
import TextPrompt.TextPrompt;
import mongoDB.PanelSeleccionarDB;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import java.awt.FlowLayout;

public class PanelInsertar extends JPanel {

	private static final long serialVersionUID = 9101169290202294993L;
	
	
	private JTable table;
	private JTable table_1;
	
	private JScrollPane scrollPane;
	private JScrollPane scrollPane_1;
	
	private DefaultTableModel model;
	
	private static int filas_table = 0;
	private static int filas_table1 = 0;
	
	private JTextField text_key;
	private JTextField text_string;
	private JTextField text_int;
	private JComboBox<Boolean> combo_boolean;
	private JTextField text_array;
	private JTextField text_keySecundary;
	private JTextField text_stringSecundary;
	
	private List<ListInserts> list = new LinkedList<ListInserts>();
	
	private JLabel lbl_imagen;
	@SuppressWarnings("unused")
	private TextPrompt placeholder;
	
	private PanelSeleccionarDB panelCreateDB = new PanelSeleccionarDB();

	private JPanel panel_2;
	private JPanel panel_3;
	
	private JDateChooser dateChooser;
	
	private JComboBox<String> comboBox;

	public PanelInsertar() {
		setLayout(new BorderLayout(0, 0));
		setSize(1013, 618);

		JPanel panel = new JPanel();
		add(panel, BorderLayout.NORTH);

		final ImageIcon tick = new ImageIcon("src\\Imagenes\\tick.png");
		final ImageIcon x = new ImageIcon("src\\Imagenes\\x.png");
		
		comboBox = new JComboBox<String>();
		comboBox.setModel(new DefaultComboBoxModel<String>(new String [] {"String", "Date", "Integer", "Boolean", "Array", "Embedded Document"}));
		comboBox.setPreferredSize(new Dimension(100, 20));
		panel.add(comboBox);

		lbl_imagen = new JLabel();
		lbl_imagen.setPreferredSize(new Dimension(40, 30));
		panel.add(lbl_imagen);

		panel_2 = new JPanel();
		panel.add(panel_2);
		
		panel_3 = new JPanel();
		panel_3.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		add(panel_3, BorderLayout.CENTER);
		
		text_key = new JTextField();
		panel_2.add(text_key);
		text_key.setColumns(10);
		placeholder = new TextPrompt("Key", text_key);

		text_string = new JTextField();
		panel_2.add(text_string);
		text_string.setColumns(10);
		placeholder = new TextPrompt("Value", text_string);

		dateChooser = new JDateChooser();
		dateChooser.setPreferredSize(new Dimension(112, 20));
		panel_2.add(dateChooser);
		
		text_int = new JTextField();
		panel_2.add(text_int);
		text_int.setColumns(10);
		placeholder = new TextPrompt("N�mero", text_int);
		
		combo_boolean = new JComboBox<Boolean>();
		combo_boolean.setModel(new DefaultComboBoxModel<Boolean>(new Boolean [] {true, false}));
		combo_boolean.setPreferredSize(new Dimension(100, 20));
		panel_2.add(combo_boolean);
		
		text_array = new JTextField();
		panel_2.add(text_array);
		text_array.setColumns(10);
		placeholder = new TextPrompt("Value del Array", text_array);
		
		text_keySecundary = new JTextField();
		panel_2.add(text_keySecundary);
		text_keySecundary.setColumns(5);
		placeholder = new TextPrompt("Key Secundary", text_keySecundary);

		text_stringSecundary = new JTextField();
		panel_2.add(text_stringSecundary);
		text_stringSecundary.setColumns(5);
		placeholder = new TextPrompt("Value Secundary", text_stringSecundary);

		
		//Tablas con sus respectivos ScrollPanel
		table = new JTable(0, 0);
		model = (DefaultTableModel) table.getModel();
		model.addColumn("Key");
		model.addColumn("Value");
		
		scrollPane = new JScrollPane(table);
		scrollPane.setPreferredSize(new Dimension(500, 300));
		panel_3.add(scrollPane);
		
		table_1 = new JTable(0, 0);
		model = (DefaultTableModel) table_1.getModel();
		model.addColumn("Value");
		scrollPane_1 = new JScrollPane(table_1);
		
		scrollPane_1.setPreferredSize(new Dimension(500, 300));
		scrollPane_1.setVisible(false);
		panel_3.add(scrollPane_1);
		
		//Acciones de los botones
		JButton btn_a�adir = new JButton("A\u00F1adir Fila");
		btn_a�adir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (text_string.isVisible()) {
					if (text_key.getText().length() != 0 && text_string.getText().length() != 0) {
						model = (DefaultTableModel) table.getModel();
						model.addRow(new Object[filas_table]);

						model.setValueAt(text_key.getText(), filas_table, 0);
						model.setValueAt(text_string.getText(), filas_table, 1);
						ListInserts insertarSt = new ListInserts();
						insertarSt.setKey(text_key.getText());
						insertarSt.setValueString(text_string.getText());
						list.add(insertarSt);

						text_key.setText(null);
						text_string.setText(null);
						filas_table++;
						lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					}
				} else if (dateChooser.isVisible()) {
					if (text_key.getText().length() != 0 && dateChooser.getDate()!=null) {
						model = (DefaultTableModel) table.getModel();
						model.addRow(new Object[filas_table]);
						
						model.setValueAt(text_key.getText(), filas_table, 0);
						model.setValueAt(dateChooser.getDate(), filas_table, 1);
						ListInserts insertarSt = new ListInserts();
						insertarSt.setKey(text_key.getText());
						insertarSt.setValueDate(dateChooser.getDate());
						list.add(insertarSt);
						
						text_key.setText(null);
						dateChooser.setDate(null);
						filas_table++;
						lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					}
				} else if (text_int.isVisible()) {
					if (text_key.getText().length() != 0 && text_int.getText()!=null) {
						model = (DefaultTableModel) table.getModel();
						model.addRow(new Object[filas_table]);

						model.setValueAt(text_key.getText(), filas_table, 0);
						model.setValueAt(Integer.parseInt(text_int.getText()), filas_table, 1);
						ListInserts insertarSt = new ListInserts();
						insertarSt.setKey(text_key.getText());
						insertarSt.setValueInt(Integer.parseInt(text_int.getText()));
						list.add(insertarSt);
						
						text_key.setText(null);
						text_int.setText(null);
						filas_table++;
						lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					}
				}  else if (combo_boolean.isVisible()) {
					if (text_key.getText().length() != 0) {
						model = (DefaultTableModel) table.getModel();
						model.addRow(new Object[filas_table]);
						
						model.setValueAt(text_key.getText(), filas_table, 0);
						model.setValueAt(combo_boolean.getSelectedItem().toString(), filas_table, 1);
						ListInserts insertarSt = new ListInserts();
						insertarSt.setKey(text_key.getText());
						insertarSt.setValueBoolean(Boolean.parseBoolean(combo_boolean.getSelectedItem().toString()));
						list.add(insertarSt);
						
						text_key.setText(null);
						filas_table++;
						lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					}
				} else if (text_array.isVisible()) {
					if (text_key.getText().length() != 0) {
						model = (DefaultTableModel) table_1.getModel();
						model.addRow(new Object[filas_table]);

						model.setValueAt(text_array.getText(), filas_table1, 0);

						text_array.setText(null);
						filas_table1++;
						lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					}
				} else if (text_keySecundary.isVisible() && text_stringSecundary.isVisible()) {
					if (text_key.getText().length() != 0) {
						model = (DefaultTableModel) table_1.getModel();
						model.addRow(new Object[filas_table]);

						model.setValueAt(text_keySecundary.getText(), filas_table1, 0);
						model.setValueAt(text_stringSecundary.getText(), filas_table1, 1);

						text_keySecundary.setText(null);
						text_stringSecundary.setText(null);
						
						filas_table1++;
						lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					}
				}

			}
		});
		
		//Bot�n eliminar fila
		JButton btn_eliminar = new JButton("Eliminar Fila");
		btn_eliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model = (DefaultTableModel) table.getModel();
				list.remove(table.getSelectedRow());
				model.removeRow(table.getSelectedRow());
				filas_table--;
			}
		});

		panel.add(btn_a�adir);
		panel.add(btn_eliminar);

		JPanel panel_1 = new JPanel();
		add(panel_1, BorderLayout.SOUTH);
		
		//Bot�n insertar en la colecci�n
		JButton btn_insertar = new JButton("Insertar en el Documento");
		btn_insertar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Insertar en la tabla normal
				if (!text_array.isVisible() && !text_keySecundary.isVisible()) {
					if (!list.isEmpty()) {
						panelCreateDB.insertar(list);
						model = (DefaultTableModel) table.getModel();
						int rows = table.getRowCount();
						for (int i = 0; rows > i; i++) {
							model.removeRow(0);
							list.remove(0);
							filas_table--;
						}
						lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					}
				//Texto Visible del Array, Insertar en la segunda tabla
				}else if (text_array.isVisible()) {
					if (filas_table1>0 && text_key.getText().length() != 0) {
						model = (DefaultTableModel) table_1.getModel();
						int rows = table_1.getRowCount();
						ArrayList<String> arrayList = new ArrayList<String>();
						for (int i = 0; rows > i; i++) {
							arrayList.add(model.getValueAt(0, 0).toString());
							model.removeRow(0);
							filas_table1--;
						}
						insertarArray(text_key.getText(), arrayList);
						comboBox.setSelectedItem("String");
						lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					}
				//Insertar en la segunda tabla un Map
				}else if (text_keySecundary.isVisible()) {
					if (filas_table1>0 && text_key.getText().length() != 0) {
						model = (DefaultTableModel) table_1.getModel();
						int rows = table_1.getRowCount();
						HashMap<String, String> hashMap = new HashMap<String, String>();
						for (int i = 0; rows > i; i++) {
							hashMap.put(model.getValueAt(0, 0).toString(), model.getValueAt(0, 1).toString());
							model.removeRow(0);
							filas_table1--;
						}
						insertarMap(text_key.getText(), hashMap);
						comboBox.setSelectedItem("String");
						lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					}
				}
			}
		});
		panel_1.add(btn_insertar);

		detectarEscritura(text_key);
		detectarEscritura(text_string);
		
		
		//Hacer o no visibles los tipos de datos
		text_key.setVisible(true);
		text_string.setVisible(true);
		dateChooser.setVisible(false);
		text_int.setVisible(false);
		combo_boolean.setVisible(false);
		text_array.setVisible(false);
		text_keySecundary.setVisible(false);
		text_stringSecundary.setVisible(false);
		
		actionPerformed(comboBox);
		detectarNumeros(text_int);
		

	}
	
	private final void actionPerformed(JComboBox<String> box) {
		box.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (comboBox.getSelectedItem().toString()=="String") {
					text_string.setVisible(true);
					dateChooser.setVisible(false);
					text_int.setVisible(false);
					combo_boolean.setVisible(false);
					text_array.setVisible(false);
					scrollPane.setVisible(true);
					scrollPane_1.setVisible(false);
					text_keySecundary.setVisible(false);
					text_stringSecundary.setVisible(false);
					text_key.setColumns(10);
					panel_2.validate();
					validate();
				}else if (comboBox.getSelectedItem().toString()=="Date") {
					text_string.setVisible(false);
					dateChooser.setVisible(true);
					text_int.setVisible(false);
					combo_boolean.setVisible(false);
					text_array.setVisible(false);
					scrollPane.setVisible(true);
					scrollPane_1.setVisible(false);
					text_keySecundary.setVisible(false);
					text_stringSecundary.setVisible(false);
					text_key.setColumns(10);
					panel_2.validate();
					validate();
				}else if (comboBox.getSelectedItem().toString()=="Integer") {
					text_string.setVisible(false);
					dateChooser.setVisible(false);
					text_int.setVisible(true);
					combo_boolean.setVisible(false);
					text_array.setVisible(false);
					scrollPane.setVisible(true);
					scrollPane_1.setVisible(false);
					text_keySecundary.setVisible(false);
					text_stringSecundary.setVisible(false);
					text_key.setColumns(10);
					panel_2.validate();
					validate();
				}else if (comboBox.getSelectedItem().toString()=="Boolean") {
					text_string.setVisible(false);
					dateChooser.setVisible(false);
					text_int.setVisible(false);
					combo_boolean.setVisible(true);
					text_array.setVisible(false);
					scrollPane.setVisible(true);
					scrollPane_1.setVisible(false);
					text_keySecundary.setVisible(false);
					text_stringSecundary.setVisible(false);
					text_key.setColumns(10);
					panel_2.validate();
					validate();
				}else if (comboBox.getSelectedItem().toString()=="Array") {
					text_string.setVisible(false);
					dateChooser.setVisible(false);
					text_int.setVisible(false);
					combo_boolean.setVisible(false);
					text_array.setVisible(true);
					scrollPane.setVisible(false);
					scrollPane_1.setVisible(true);
					text_keySecundary.setVisible(false);
					text_stringSecundary.setVisible(false);
					text_key.setColumns(10);
					eliminarColumnaTabla(table_1);
					panel_2.validate();
					validate();
				}else if (comboBox.getSelectedItem().toString()=="Embedded Document") {
					text_string.setVisible(false);
					dateChooser.setVisible(false);
					text_int.setVisible(false);
					combo_boolean.setVisible(false);
					text_array.setVisible(false);
					scrollPane.setVisible(false);
					scrollPane_1.setVisible(true);
					text_keySecundary.setVisible(true);
					text_stringSecundary.setVisible(true);
					text_key.setColumns(5);
					insertarColumnaTabla(table_1, "Value Secundary");
					panel_2.validate();
					validate();
				}
			}
		});
	}
	
	/*M�todo privado para actualizar la tabla y a�adir 
	 * o quitar una columna dependiendo de si es un Array o un Map
	 * */
	private void insertarColumnaTabla(JTable tabla, String nombre) {
		model = (DefaultTableModel) tabla.getModel();
		try {
			if (model.getColumnCount() == 1) {
				model.addColumn(nombre);
				
			}
		}catch(Exception e) {}
	}
	
	//M�todo eliminar una columna
	private void eliminarColumnaTabla(JTable tabla) {
		model = (DefaultTableModel) tabla.getModel();
		try {
			if (model.getColumnCount() > 1) {
				tabla.removeColumn(tabla.getColumnModel().getColumn(1));
				model.setColumnCount(1);
				
			}
		}catch(Exception e) {
			
		}
	}
	
	//M�todo para insertar el Array en la tabla principal y en mi lista de objetos
	private void insertarArray(String key, ArrayList<String> arr) {
		model = (DefaultTableModel) table.getModel();
		model.addRow(new Object[filas_table]);
		
		model.setValueAt(text_key.getText(), filas_table, 0);
		model.setValueAt(arr.toString(), filas_table, 1);
		ListInserts insertarSt = new ListInserts();
		insertarSt.setKey(key);
		insertarSt.setValueArr(arr);
		list.add(insertarSt);
		
		text_key.setText(null);
		filas_table++;
	}
	
	//M�todo para insertar el Map en la tabla principal y en mi lista de objetos
	private void insertarMap(String key, HashMap<String, String> map) {
		model = (DefaultTableModel) table.getModel();
		model.addRow(new Object[filas_table]);
		
		model.setValueAt(text_key.getText(), filas_table, 0);
		model.setValueAt(map.toString(), filas_table, 1);
		ListInserts insertarSt = new ListInserts();
		insertarSt.setKey(key);
		insertarSt.setValueMap(map);
		list.add(insertarSt);
		
		text_key.setText(null);
		filas_table++;
	}
	
	//M�todo que me detecta si escribo otra cosa que no sea un n�mero me lo elimina
	private void detectarNumeros(JTextField text) {
		text.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if (!Character.isDigit(c)) {
					e.consume();
				}
			}
		});
	}
	
	//M�todo para detectar la escritura y borrar la imagen de la pantalla
	private void detectarEscritura(JTextField text) {
		text.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if (!Character.isDigit(c) || Character.isDigit(c)) {
					lbl_imagen.setIcon(null);
				}
			}
		});
	}
}
