package mongoDB.panel;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.JTextPane;
import mongoDB.PanelSeleccionarDB;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class PanelInsertarJSON extends JPanel {

	
	private static final long serialVersionUID = -8609645022710596597L;
	private PanelSeleccionarDB panelCreateDB = new PanelSeleccionarDB();

	public PanelInsertarJSON() {
		setLayout(new BorderLayout(0, 0));
		setSize(1013, 618);
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.SOUTH);
		
		JPanel panel_1 = new JPanel();
		add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.X_AXIS));
		
		JTextPane text_json = new JTextPane();
		
		JScrollPane scrollPane = new JScrollPane(text_json);
		scrollPane.setPreferredSize(new Dimension(500, 300));
		panel_1.add(scrollPane);
		
		
		
		JButton btn_insertarJSON = new JButton("Insertar JSON");
		btn_insertarJSON.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					panelCreateDB.insertarJSON(text_json.getText());
					text_json.setText("");
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		panel.add(btn_insertarJSON);
		
		
	}

}
