package mongoDB.panel;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PanelCambioInsertar extends JPanel {

	
	private static final long serialVersionUID = 8474066622589678652L;
	private JPanel panel_cambios;
	private JButton btn_insertarNormal;
	private JButton btn_insertarJSON;
	private PanelInsertar panel_insertar = new PanelInsertar();
	private PanelInsertarJSON panel_insertarJSON = new PanelInsertarJSON();

	public PanelCambioInsertar() {
		setLayout(new BorderLayout(0, 0));
		setSize(1013, 618);
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.NORTH);
		
		btn_insertarNormal = new JButton("Insertar Normal");
		btn_insertarNormal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		panel.add(btn_insertarNormal);
		
		btn_insertarJSON = new JButton("Insertar JSON");
		panel.add(btn_insertarJSON);
		
		
		panel_cambios = new JPanel();
		add(panel_cambios, BorderLayout.CENTER);
		
		panel_cambios.add(panel_insertar);
		panel_insertar.setVisible(true);
		panel_insertarJSON.setVisible(false);
		deshabilitarBotones();
		
		actionPerformed(btn_insertarNormal);
		actionPerformed(btn_insertarJSON);
	}
	
	private void deshabilitarBotones() {
		if (panel_insertar.isVisible()) {
			btn_insertarNormal.setEnabled(false);
			btn_insertarJSON.setEnabled(true);
		}else if (panel_insertarJSON.isVisible()) {
			btn_insertarNormal.setEnabled(true);
			btn_insertarJSON.setEnabled(false);
		}
	}
	
	private final void actionPerformed(JButton btn) {
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object evt = e.getSource();
				if (evt.equals(btn_insertarNormal)) {
					panel_insertarJSON.setVisible(false);
					panel_insertar.setVisible(true);
					panel_cambios.add(panel_insertar);
					panel_cambios.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_insertarJSON)) {
					panel_insertar.setVisible(false);
					panel_insertarJSON.setVisible(true);
					panel_cambios.add(panel_insertarJSON);
					panel_cambios.validate();
					deshabilitarBotones();
				}
			}
		});
	}
}
