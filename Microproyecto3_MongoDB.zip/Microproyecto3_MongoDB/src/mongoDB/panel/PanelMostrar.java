package mongoDB.panel;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import mongoDB.Connection;
import mongoDB.PanelSeleccionarDB;
import java.awt.Color;
import javax.swing.JTextField;

import TextPrompt.TextPrompt;

public class PanelMostrar extends JPanel {

	private static final long serialVersionUID = 448656932495544037L;

	private final JTextArea textArea;
	private Connection connection;
	private PanelSeleccionarDB panelCreateDB = new PanelSeleccionarDB();
	private JButton btn_encontrar;
	private JButton btn_todo;
	private JPanel panel_DB;
	private JTextField text_value;
	private JTextField text_key;
	@SuppressWarnings("unused")
	private TextPrompt placeholder;

	public PanelMostrar() {
		setLayout(new BorderLayout(0, 0));
		setSize(1013, 618);
		
		panel_DB = new JPanel();
		add(panel_DB, BorderLayout.NORTH);
		
		text_key = new JTextField();
		panel_DB.add(text_key);
		text_key.setColumns(10);
		placeholder = new TextPrompt("Key", text_key);
		
		text_value = new JTextField();
		panel_DB.add(text_value);
		text_value.setColumns(10);
		placeholder = new TextPrompt("Value", text_value);
		
		btn_todo = new JButton("Mostrar Todo");
		panel_DB.add(btn_todo);
		
		btn_encontrar = new JButton("Encontrar");
		panel_DB.add(btn_encontrar);
		
		JLabel level = new JLabel();
		level.setPreferredSize(new Dimension(50, 0));
		add(level, BorderLayout.WEST);
		
		JLabel level3 = new JLabel();
		level3.setPreferredSize(new Dimension(50, 0));
		add(level3, BorderLayout.EAST);
		
		
		
		textArea = new JTextArea();
		textArea.setEditable(false);
		
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setPreferredSize(new Dimension(700, 300));
		add(scrollPane, BorderLayout.CENTER);
		
		JPanel panel = new JPanel();
		level3.setPreferredSize(new Dimension(50, 0));
		add(panel, BorderLayout.SOUTH);
		
		JButton btn_mostrar = new JButton("Mostrar");
		btn_mostrar.setPreferredSize(new Dimension(150, 60));
		btn_mostrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!text_key.isVisible()) {
					connection = panelCreateDB.mostrar();
					if (!connection.getBuffer().toString().isEmpty()) {
						textArea.setForeground(Color.BLACK);
						textArea.setText(connection.getBuffer().toString());
						connection.cleanBuffer();
					}else {
						textArea.setForeground(Color.RED);
						textArea.setText("La colecci�n esta vac�a");
					}
				}else {
					connection = panelCreateDB.encontrar(text_key.getText(), text_value.getText());
					if (text_key.getText().length() != 0 && text_value.getText().length() != 0) {
						if (!connection.getBuffer().toString().isEmpty()) {
							textArea.setForeground(Color.BLACK);
							textArea.setText(connection.getBuffer().toString());
							connection.cleanBuffer();
						}else {
							textArea.setForeground(Color.RED);
							textArea.setText("No se ha encontrado ning�n resultado");
						}
					}else {
						textArea.setForeground(Color.RED);
						textArea.setText("Rellena todos los campos");
					}
				}
			}
		});
		panel.add(btn_mostrar);
		
		btn_todo.setEnabled(false);
		text_key.setVisible(false);
		text_value.setVisible(false);
		
		actionPerformed(btn_todo);
		actionPerformed(btn_encontrar);
	}
	
	private void deshabilitarBotones() {
		if (!text_key.isVisible()) {
			btn_todo.setEnabled(false);
			btn_encontrar.setEnabled(true);
		}else {
			btn_todo.setEnabled(true);
			btn_encontrar.setEnabled(false);
		}
	}
	
	private final void actionPerformed(JButton btn) {
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object evt = e.getSource();
				if (evt.equals(btn_todo)) {
					text_key.setVisible(false);
					text_value.setVisible(false);
					panel_DB.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_encontrar)) {
					text_key.setVisible(true);
					text_value.setVisible(true);
					panel_DB.validate();
					deshabilitarBotones();
				}
			}
		});
	}
	

}
