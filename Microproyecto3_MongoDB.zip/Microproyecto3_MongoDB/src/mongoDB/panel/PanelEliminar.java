package mongoDB.panel;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import com.mongodb.DBCursor;
import mongoDB.PanelSeleccionarDB;

public class PanelEliminar extends JPanel {

	private static final long serialVersionUID = -5873219090418941854L;

	private JTable table;
	private JScrollPane scrollPane;
	private DefaultTableModel model;
	private PanelSeleccionarDB panelSeleccionarDB = new PanelSeleccionarDB();
	private int filas = 0;
	private JLabel lbl_imagen;

	public PanelEliminar() {
		setLayout(new BorderLayout(0, 0));
		setSize(1013, 618);
		
		table = new JTable(0, 1);
		table.getColumn("A").setHeaderValue("Collection");

		scrollPane = new JScrollPane(table);
		scrollPane.setPreferredSize(new Dimension(500, 300));
		add(scrollPane, BorderLayout.CENTER);
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.NORTH);
		
		final ImageIcon tick = new ImageIcon("src\\Imagenes\\tick.png");
		final ImageIcon x = new ImageIcon("src\\Imagenes\\x.png");
		
		
		JButton btn_eliminar = new JButton("Eliminar");
		btn_eliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lbl_imagen.setIcon(null);
				if (table.getSelectedRow()!=-1) {
					lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
					int num = table.getSelectedRow();
					model = (DefaultTableModel) table.getModel();
					model.removeRow(num);
					panelSeleccionarDB.eliminar(num);
					filas--;
				}else {
					lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(30, 20, Image.SCALE_DEFAULT)));
				}
			}
		});
		
		JButton btn_actualizar = new JButton("Refrescar");
		btn_actualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lbl_imagen.setIcon(null);
				eliminarTabla();
				DBCursor cursor = panelSeleccionarDB.getCollection().find();
				model = (DefaultTableModel) table.getModel();
				try {
					while (cursor.hasNext()) {
						model.addRow(new Object[filas]);
						model.setValueAt(cursor.next().toString(), filas, 0);
						filas++;
					}
				} finally {
					  cursor.close(); 
				}
			}
		});
		lbl_imagen = new JLabel();
		lbl_imagen.setPreferredSize(new Dimension(40, 30));
		panel.add(lbl_imagen);
		panel.add(btn_actualizar);
		panel.add(btn_eliminar);
	}
	
	private void eliminarTabla() {
		model = (DefaultTableModel) table.getModel();
		for(int i=filas-1; i>=0; i--){
			model.removeRow(i);
			filas --;
		}
	}

}
