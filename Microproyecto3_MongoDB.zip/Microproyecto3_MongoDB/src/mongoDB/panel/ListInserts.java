package mongoDB.panel;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class ListInserts implements java.io.Serializable{
	
	private static final long serialVersionUID = -4916358342901011401L;
	
	private String key;
	private String valueNormal;
	private Date valueDate;
	private int valueInt;
	private boolean valueBoolean;
	private boolean isTrue;
	private ArrayList<String> valueArr;
	private HashMap<String, String> valueMap;
	
	public ListInserts() {
		
	}

	public String getKey() {
		return key;
	}

	public void setKey(String titulo) {
		this.key = titulo;
	}

	public String getValueString() {
		return valueNormal;
	}

	public void setValueString(String accion) {
		this.valueNormal = accion;
	}
	
	public Date getValueDate() {
		return valueDate;
	}

	public void setValueDate(Date accionDate) {
		this.valueDate = accionDate;
	}
	
	public int getValueInt() {
		return valueInt;
	}

	public void setValueInt(int num) {
		this.valueInt = num;
	}
	
	public boolean getValueBoolean() {
		return valueBoolean;
	}

	public void setValueBoolean(boolean valueBoolean) {
		setTrue(true);
		this.valueBoolean = valueBoolean;
	}
	
	public boolean isTrue() {
		return isTrue;
	}
	
	private void setTrue(boolean isTrue) {
		this.isTrue = isTrue;
	}

	public ArrayList<String> getValueArr() {
		return valueArr;
	}

	public void setValueArr(ArrayList<String> valueArr) {
		this.valueArr = valueArr;
	}

	public HashMap<String, String> getValueMap() {
		return valueMap;
	}

	public void setValueMap(HashMap<String, String> valueMap) {
		this.valueMap = valueMap;
	}
}
