package mongoDB;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.function.Consumer;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import org.bson.Document;

import com.mongodb.Block;

import TextPrompt.TextPrompt;
import java.awt.FlowLayout;
import java.awt.SystemColor;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Color;
import javax.swing.JComboBox;

public class PanelCreateDB extends JPanel {

	private static final long serialVersionUID = -1259609168698996891L;
	
	private static String textIndexDB;
	private static String textIndexColl;
	
	private JTextField textDB;
	private JTextField textCollection;
	private Connection conexion = new Connection();
	private JLabel lbl_imagen;
	private TextPrompt placeholder;
	private JPanel panel_2;
	private JButton btn_crearDB;
	private JButton btn_eliminarDB;
	private JButton btn_eliminarCollection;
	private JPanel panel_created;
	
	private final JTextArea textArea;
	private JScrollPane scrollPane;
	
	private final ImageIcon tick = new ImageIcon("src\\Imagenes\\tick.png");
	private final ImageIcon x = new ImageIcon("src\\Imagenes\\x.png");
	//Botones acci�n
	private JButton btn_createDB;
	private JButton btn_dropDB;
	private JButton btn_dropCollec;
	private JPanel panel;
	private JButton btn_verCollections;
	private JButton btn_verDBs;
	private JButton btn_mostrarCollections;
	private JButton btn_contarColl;
	private JButton btn_contar;
	private JButton btn_createIndex;
	private JButton btn_crearIndices;
	private JTextField text_createIndex;
	private JPanel panel_central1;
	private JPanel panel_central2;
	private JComboBox<String> comboBox;
	private JButton btn_eliminarIndex;
	private JButton btn_dropIndice;
	private JButton btn_mostrarIndex;
	private JButton btn_mostrarIndices;

	public PanelCreateDB() {
		setLayout(new BorderLayout(0, 0));
		setSize(1013, 618);
		
		panel = new JPanel();
		panel.setPreferredSize(new Dimension(0, 200));
		add(panel, BorderLayout.SOUTH);
		
		btn_createDB = new JButton("Crear DB");
		btn_createDB.setPreferredSize(new Dimension(150, 60));
		panel.add(btn_createDB);
		
		btn_crearIndices = new JButton("Crear Indice");
		btn_crearIndices.setPreferredSize(new Dimension(150, 60));
		panel.add(btn_crearIndices);
		
		btn_dropIndice = new JButton("Eliminar Indice");
		btn_dropIndice.setPreferredSize(new Dimension(150, 60));
		panel.add(btn_dropIndice);
		
		btn_dropDB = new JButton("Eliminar DB");
		btn_dropDB.setPreferredSize(new Dimension(150, 60));
		panel.add(btn_dropDB);
		
		btn_dropCollec = new JButton("Eliminar Colecci�n");
		btn_dropCollec.setPreferredSize(new Dimension(150, 60));
		panel.add(btn_dropCollec);
		
		btn_mostrarCollections = new JButton("Mostrar");
		btn_mostrarCollections.setPreferredSize(new Dimension(150, 60));
		panel.add(btn_mostrarCollections);
		
		btn_contar = new JButton("Contar");
		btn_contar.setPreferredSize(new Dimension(150, 60));
		panel.add(btn_contar);
		
		btn_mostrarIndices = new JButton("Mostrar Indices");
		btn_mostrarIndices.setPreferredSize(new Dimension(150, 60));
		panel.add(btn_mostrarIndices);
		
		JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(300, 0));
		add(panel_1, BorderLayout.WEST);
		
		btn_verDBs = new JButton("Ver DBs");
		btn_verDBs.setBackground(new Color(152, 251, 152));
		
		btn_verCollections = new JButton("Ver Collections");
		btn_verCollections.setBackground(new Color(152, 251, 152));
		
		btn_contarColl = new JButton("Contar Colecciones");
		btn_contarColl.setBackground(new Color(152, 251, 152));
		
		btn_mostrarIndex = new JButton("Ver Index");
		btn_mostrarIndex.setBackground(new Color(152, 251, 152));
		
		panel_2 = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panel_2.getLayout();
		flowLayout.setVgap(80);
		panel_2.setPreferredSize(new Dimension(0, 200));
		add(panel_2, BorderLayout.NORTH);
		
		btn_crearDB = new JButton("Crear Base Datos");
		btn_crearDB.setBackground(SystemColor.activeCaption);
		btn_crearDB.setPreferredSize(new Dimension(150, 40));
		panel_2.add(btn_crearDB);
		
		btn_createIndex = new JButton("Crear Indice");
		btn_createIndex.setBackground(SystemColor.activeCaption);
		btn_createIndex.setPreferredSize(new Dimension(150, 40));
		panel_2.add(btn_createIndex);
		
		btn_eliminarIndex = new JButton("Eliminar Indice");
		btn_eliminarIndex.setBackground(SystemColor.activeCaption);
		btn_eliminarIndex.setPreferredSize(new Dimension(150, 40));
		panel_2.add(btn_eliminarIndex);
		
		btn_eliminarDB = new JButton("Eliminar Base de Datos");
		btn_eliminarDB.setBackground(SystemColor.activeCaption);
		btn_eliminarDB.setPreferredSize(new Dimension(180, 40));
		panel_2.add(btn_eliminarDB);
		
		btn_eliminarCollection = new JButton("Eliminar Collection");
		btn_eliminarCollection.setBackground(SystemColor.activeCaption);
		btn_eliminarCollection.setPreferredSize(new Dimension(150, 40));
		panel_2.add(btn_eliminarCollection);
		
		panel_created = new JPanel();
		add(panel_created, BorderLayout.CENTER);
		
		panel_central1 = new JPanel();
		panel_central1.setPreferredSize(new Dimension(300, 100));
		panel_central1.setLayout(new BorderLayout(0, 0));
		panel_created.add(panel_central1);
		
		panel_central2 = new JPanel();
		panel_central2.setLayout(new BorderLayout(0, 0));
		panel_created.add(panel_central2);
		
		textDB = new JTextField();
		textDB.setHorizontalAlignment(SwingConstants.CENTER);
		textDB.setFont(new Font("Arial", textDB.getFont().getStyle() & ~Font.ITALIC | Font.BOLD, textDB.getFont().getSize() + 8));
		textDB.setPreferredSize(new Dimension(0, 50));
		panel_central1.add(textDB, BorderLayout.NORTH);
		textDB.setColumns(10);
		placeholder = new TextPrompt("Base de Datos", textDB);
		placeholder.setHorizontalAlignment(SwingConstants.CENTER);
		
		comboBox = new JComboBox<String>();
		comboBox.setModel(new DefaultComboBoxModel<String>(new String [] {"Ascendente", "Descendente"}));
		panel_central2.add(comboBox, BorderLayout.NORTH);
		
		text_createIndex = new JTextField();
		text_createIndex.setHorizontalAlignment(SwingConstants.CENTER);
		text_createIndex.setFont(new Font("Arial", text_createIndex.getFont().getStyle() & ~Font.ITALIC | Font.BOLD, text_createIndex.getFont().getSize() + 8));
		text_createIndex.setPreferredSize(new Dimension(0, 50));
		panel_central2.add(text_createIndex, BorderLayout.SOUTH);
		text_createIndex.setColumns(10);
		placeholder = new TextPrompt("Indice", text_createIndex);
		placeholder.setHorizontalAlignment(SwingConstants.CENTER);
		
		textCollection = new JTextField();
		textCollection.setHorizontalAlignment(SwingConstants.CENTER);
		textCollection.setFont(new Font("Arial", textCollection.getFont().getStyle() & ~Font.ITALIC | Font.BOLD, textCollection.getFont().getSize() + 8));
		textCollection.setPreferredSize(new Dimension(0, 50));
		panel_central1.add(textCollection, BorderLayout.SOUTH);
		textCollection.setColumns(10);
		placeholder = new TextPrompt("Colecci�n", textCollection);
		placeholder.setHorizontalAlignment(SwingConstants.CENTER);
		
		//Text Area
		textArea = new JTextArea();
		textArea.setEditable(false);
		
		scrollPane = new JScrollPane(textArea);
		panel_central1.add(scrollPane);
		
		//Imagenes
		lbl_imagen = new JLabel();
		lbl_imagen.setPreferredSize(new Dimension(300, 0));
		add(lbl_imagen, BorderLayout.EAST);
		
		//Acciones de los botones
		//Crear Base de Datos
		btn_createDB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textDB.getText().length() != 0 && textCollection.getText().length() != 0) {
					conexion.crearBaseDatos(textDB.getText(), textCollection.getText());
					lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
				}else {
					lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
				}
				textDB.setText(null);
				textCollection.setText(null);
			}
		});
		
		//Crear Indices
		btn_crearIndices.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				if (panel_central2.isVisible()) {
					if (text_createIndex.getText().length() != 0) {
						if (comboBox.getSelectedItem().toString() == "Ascendente") {
							conexion.crearIndicesAcendentes(textIndexDB, textIndexColl, text_createIndex.getText());
							lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
						} else {
							conexion.crearIndicesDescendentes(textIndexDB, textIndexColl, text_createIndex.getText());
							lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
						}
						text_createIndex.setText(null);
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
					}
				} else {
					if (textDB.getText().length() != 0 && textCollection.getText().length() != 0) {
						if (conexion.getMongo().getDB(textDB.getText()).collectionExists(textCollection.getText())) {
							panel_central1.setVisible(false);
							panel_central2.setVisible(true);
							comboBox.setVisible(true);
							panel_created.validate();
							textIndexDB = textDB.getText();
							textIndexColl = textCollection.getText();
							lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
							textDB.setText(null);
							textCollection.setText(null);
						} else {
							lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
						}
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
					}
				}
			}
		});
		
		//Eliminar Indice
		btn_dropIndice.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				if (panel_central2.isVisible()) {
					if (text_createIndex.getText().length() != 0) {
						if (comboBox.getSelectedItem().toString() == "Ascendente") {
							if (conexion.eliminarIndice(textIndexDB, textIndexColl, text_createIndex.getText()))
								lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
							else 
								lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
						}
						text_createIndex.setText(null);
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
					}
				} else {
					if (textDB.getText().length() != 0 && textCollection.getText().length() != 0) {
						if (conexion.getMongo().getDB(textDB.getText()).collectionExists(textCollection.getText())) {
							panel_central1.setVisible(false);
							panel_central2.setVisible(true);
							comboBox.setVisible(false);
							panel_created.validate();
							textIndexDB = textDB.getText();
							textIndexColl = textCollection.getText();
							lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
							textDB.setText(null);
							textCollection.setText(null);
						} else {
							lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
						}
					} else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
					}
				}
			}
		});
		
		//Mostrar Indices
		btn_mostrarIndices.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textDB.getText().length() != 0 && textCollection.getText().length() != 0) {
					StringBuffer buffer = new StringBuffer(); 
					conexion.mostrarIndices(textDB.getText(), textCollection.getText()).forEach(new Consumer<Document>() {
							@Override
							public void accept(Document document) {
								buffer.append(document.toString() + "\n");
							}
						});
					scrollPane.setVisible(true);
					textDB.setVisible(false);
					textCollection.setVisible(false);
					panel_created.validate();
					textArea.setText(buffer.toString());
					textDB.setText(null);
					textCollection.setText(null);
				}
			}
		});
		
		//Eliminar Base de Datos
		btn_dropDB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textDB.getText().length() != 0) {
					if (conexion.eliminarBaseDatos(textDB.getText())) {
						lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
					}else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
					}
				}else {
					lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
				}
				textDB.setText(null);
			}
		});
		
		//Eliminar Colecci�n
		btn_dropCollec.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textDB.getText().length() != 0 && textCollection.getText().length() != 0) {
					if (conexion.eliminarCollection(textDB.getText(), textCollection.getText())) {
						lbl_imagen.setIcon(new ImageIcon(tick.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
					}else {
						lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
					}
				}else {
					lbl_imagen.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
				}
				textDB.setText(null);
				textCollection.setText(null);
			}
		});
		
		//Ver Bases de Datos
		btn_verDBs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StringBuffer buffer = new StringBuffer();
				conexion.getDBs().forEach(new Consumer<String>() {
					@Override
					public void accept(String db) {
						buffer.append(db + "\n");
					}
				});
				textArea.setText(buffer.toString());
			}
		});
		
		//Ver Colecciones
		btn_mostrarCollections.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textDB.getText().length() != 0) {
					StringBuffer buffer = new StringBuffer();
					conexion.getCollections(textDB.getText()).forEach(new Consumer<String>() {
						@Override
						public void accept(String coll) {
							buffer.append(coll + "\n");
						}
					});
					textArea.setText(buffer.toString());
				}
				textDB.setText(null);
			}
		});
		
		//Contar Colecciones
		btn_contar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textDB.getText().length() != 0 && textCollection.getText().length() != 0) {
					scrollPane.setVisible(true);
					textDB.setVisible(false);
					textCollection.setVisible(false);
					panel_created.validate();
					textArea.setText(String.valueOf(conexion.contarDocumentos(textDB.getText(), textCollection.getText())));
					textDB.setText(null);
					textCollection.setText(null);
				}
			}
		});
		
		btn_createDB.setVisible(true);
		btn_crearIndices.setVisible(false);
		btn_dropIndice.setVisible(false);
		btn_dropDB.setVisible(false);
		btn_dropCollec.setVisible(false);
		btn_mostrarCollections.setVisible(false);
		btn_contar.setVisible(false);
		btn_crearDB.setEnabled(false);
		scrollPane.setVisible(false);
		panel_central2.setVisible(false);
		btn_mostrarIndices.setVisible(false);
		
		detectarEscritura(textDB);
		detectarEscritura(textCollection);
		
		actionPerformed(btn_crearDB);
		actionPerformed(btn_createIndex);
		actionPerformed(btn_eliminarIndex);
		actionPerformed(btn_eliminarDB);
		actionPerformed(btn_eliminarCollection);
		actionPerformed(btn_mostrarIndex);
		
		actionPerformed(btn_verDBs);
		actionPerformed(btn_contarColl);
		actionPerformed(btn_verCollections);
		
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(110)
							.addComponent(btn_verDBs))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(94)
							.addComponent(btn_verCollections))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(82)
							.addComponent(btn_contarColl))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(106)
							.addComponent(btn_mostrarIndex)))
					.addContainerGap(93, Short.MAX_VALUE))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addComponent(btn_verDBs)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btn_verCollections)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btn_contarColl)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btn_mostrarIndex)
					.addContainerGap(97, Short.MAX_VALUE))
		);
		panel_1.setLayout(gl_panel_1);
	}
	
	private void detectarEscritura(JTextField text) {
		text.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if (!Character.isDigit(c) || Character.isDigit(c)) {
					lbl_imagen.setIcon(null);
				}
			}
		});
	}
	
	private void deshabilitarBotones() {
		if (btn_createDB.isVisible()) {
			btn_crearDB.setEnabled(false);
			btn_eliminarDB.setEnabled(true);
			btn_eliminarCollection.setEnabled(true);
			btn_createIndex.setEnabled(true);
			btn_eliminarIndex.setEnabled(true);
			lbl_imagen.setIcon(null);
		}else if (btn_dropDB.isVisible()) {
			btn_crearDB.setEnabled(true);
			btn_eliminarDB.setEnabled(false);
			btn_eliminarCollection.setEnabled(true);
			btn_createIndex.setEnabled(true);
			btn_eliminarIndex.setEnabled(true);
			lbl_imagen.setIcon(null);
		}else if (btn_dropCollec.isVisible()) {
			btn_crearDB.setEnabled(true);
			btn_eliminarDB.setEnabled(true);
			btn_eliminarCollection.setEnabled(false);
			btn_createIndex.setEnabled(true);
			btn_eliminarIndex.setEnabled(true);
			lbl_imagen.setIcon(null);
		}else if (scrollPane.isVisible()) {
			btn_crearDB.setEnabled(true);
			btn_eliminarDB.setEnabled(true);
			btn_eliminarCollection.setEnabled(true);
			btn_createIndex.setEnabled(true);
			btn_eliminarIndex.setEnabled(true);
			lbl_imagen.setIcon(null);
		}else if (btn_crearIndices.isVisible()) {
			btn_crearDB.setEnabled(true);
			btn_eliminarDB.setEnabled(true);
			btn_eliminarCollection.setEnabled(true);
			btn_createIndex.setEnabled(false);
			btn_eliminarIndex.setEnabled(true);
			lbl_imagen.setIcon(null);
		}else if (btn_dropIndice.isVisible()) {
			btn_crearDB.setEnabled(true);
			btn_eliminarDB.setEnabled(true);
			btn_eliminarCollection.setEnabled(true);
			btn_createIndex.setEnabled(true);
			btn_eliminarIndex.setEnabled(false);
			lbl_imagen.setIcon(null);
		}else if (btn_mostrarIndices.isVisible()) {
			btn_crearDB.setEnabled(true);
			btn_eliminarDB.setEnabled(true);
			btn_eliminarCollection.setEnabled(true);
			btn_createIndex.setEnabled(true);
			btn_eliminarIndex.setEnabled(true);
			lbl_imagen.setIcon(null);
		}else if (btn_contar.isVisible()) {
			btn_crearDB.setEnabled(true);
			btn_eliminarDB.setEnabled(true);
			btn_eliminarCollection.setEnabled(true);
			btn_createIndex.setEnabled(true);
			btn_eliminarIndex.setEnabled(true);
			lbl_imagen.setIcon(null);
		}
	}
	
	private final void actionPerformed(JButton btn) {
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object evt = e.getSource();
				if (evt.equals(btn_crearDB)) {
					btn_createDB.setVisible(true);
					btn_crearIndices.setVisible(false);
					btn_dropIndice.setVisible(false);
					btn_mostrarIndices.setVisible(false);
					btn_dropDB.setVisible(false);
					btn_dropCollec.setVisible(false);
					textDB.setVisible(true);
					textCollection.setVisible(true);
					scrollPane.setVisible(false);
					btn_mostrarCollections.setVisible(false);
					btn_contar.setVisible(false);
					panel_central1.setVisible(true);
					panel_central2.setVisible(false);
					panel.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_createIndex)) {
					btn_createDB.setVisible(false);
					btn_crearIndices.setVisible(true);
					btn_dropIndice.setVisible(false);
					btn_mostrarIndices.setVisible(false);
					btn_dropDB.setVisible(false);
					btn_dropCollec.setVisible(false);
					textDB.setVisible(true);
					textCollection.setVisible(true);
					scrollPane.setVisible(false);
					btn_mostrarCollections.setVisible(false);
					btn_contar.setVisible(false);
					panel_central1.setVisible(true);
					panel_central2.setVisible(false);
					panel.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_eliminarIndex)) {
					btn_createDB.setVisible(false);
					btn_crearIndices.setVisible(false);
					btn_dropIndice.setVisible(true);
					btn_mostrarIndices.setVisible(false);
					btn_dropDB.setVisible(false);
					btn_dropCollec.setVisible(false);
					textDB.setVisible(true);
					textCollection.setVisible(true);
					scrollPane.setVisible(false);
					btn_mostrarCollections.setVisible(false);
					btn_contar.setVisible(false);
					panel_central1.setVisible(true);
					panel_central2.setVisible(false);
					panel.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_eliminarDB)) {
					btn_createDB.setVisible(false);
					btn_crearIndices.setVisible(false);
					btn_dropIndice.setVisible(false);
					btn_mostrarIndices.setVisible(false);
					btn_dropDB.setVisible(true);
					btn_dropCollec.setVisible(false);
					textDB.setVisible(true);
					textCollection.setVisible(false);
					scrollPane.setVisible(false);
					btn_mostrarCollections.setVisible(false);
					btn_contar.setVisible(false);
					panel_central1.setVisible(true);
					panel_central2.setVisible(false);
					panel.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_eliminarCollection)) {
					btn_createDB.setVisible(false);
					btn_crearIndices.setVisible(false);
					btn_dropIndice.setVisible(false);
					btn_mostrarIndices.setVisible(false);
					btn_dropDB.setVisible(false);
					btn_dropCollec.setVisible(true);
					textDB.setVisible(true);
					textCollection.setVisible(true);
					scrollPane.setVisible(false);
					btn_mostrarCollections.setVisible(false);
					btn_contar.setVisible(false);
					panel_central1.setVisible(true);
					panel_central2.setVisible(false);
					panel.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_verDBs)) {
					btn_createDB.setVisible(false);
					btn_crearIndices.setVisible(false);
					btn_dropIndice.setVisible(false);
					btn_mostrarIndices.setVisible(false);
					btn_dropDB.setVisible(false);
					btn_dropCollec.setVisible(false);
					textDB.setVisible(false);
					textCollection.setVisible(false);
					scrollPane.setVisible(true);
					btn_mostrarCollections.setVisible(false);
					btn_contar.setVisible(false);
					panel_central1.setVisible(true);
					panel_central2.setVisible(false);
					panel.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_verCollections)) {
					btn_createDB.setVisible(false);
					btn_crearIndices.setVisible(false);
					btn_dropIndice.setVisible(false);
					btn_mostrarIndices.setVisible(false);
					btn_dropDB.setVisible(false);
					btn_dropCollec.setVisible(false);
					textDB.setVisible(true);
					textCollection.setVisible(false);
					textArea.setText(null);
					scrollPane.setVisible(true);
					btn_mostrarCollections.setVisible(true);
					btn_contar.setVisible(false);
					panel_central1.setVisible(true);
					panel_central2.setVisible(false);
					panel.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_contarColl)) {
					btn_createDB.setVisible(false);
					btn_crearIndices.setVisible(false);
					btn_dropIndice.setVisible(false);
					btn_mostrarIndices.setVisible(false);
					btn_dropDB.setVisible(false);
					btn_dropCollec.setVisible(false);
					textDB.setVisible(true);
					panel_central1.setVisible(true);
					textCollection.setVisible(true);
					textArea.setText(null);
					scrollPane.setVisible(false);
					btn_mostrarCollections.setVisible(false);
					btn_contar.setVisible(true);
					panel_central1.setVisible(true);
					panel_central2.setVisible(false);
					panel.validate();
					deshabilitarBotones();
				}else if (evt.equals(btn_mostrarIndex)) {
					btn_createDB.setVisible(false);
					btn_crearIndices.setVisible(false);
					btn_dropIndice.setVisible(false);
					btn_mostrarIndices.setVisible(true);
					btn_dropDB.setVisible(false);
					btn_dropCollec.setVisible(false);
					textDB.setVisible(true);
					panel_central1.setVisible(true);
					textCollection.setVisible(true);
					textArea.setText(null);
					scrollPane.setVisible(false);
					btn_mostrarCollections.setVisible(false);
					btn_contar.setVisible(false);
					panel_central1.setVisible(true);
					panel_central2.setVisible(false);
					panel.validate();
					deshabilitarBotones();
				}
			}
		});
	}
}
