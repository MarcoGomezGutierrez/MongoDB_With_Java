package mongoDB;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.SystemColor;

public class Principal extends JFrame {

	private static final long serialVersionUID = -4546023981469859082L;

	private JPanel panelPrincipal;
	private JPanel panel_btn;
	private JButton btn_usarDB;
	private JButton btn_editarDB;
	private JPanel panel_central;
	private final PanelSeleccionarDB panelSeleccionarDB = new PanelSeleccionarDB();
	private final PanelVerDB panelVerDB = new PanelVerDB();
	private final PanelCreateDB panelCrearDB = new PanelCreateDB();
	private JButton btn_crearDB;

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		// cd C:/Program Files/MongoDB/Server/4.4/bin
		// mongod
		// mongo
		// db.LenguajesProgramacion.find()
		UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				Principal frame = new Principal();
				frame.setVisible(true);
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1013,618);
		//setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		getContentPane().setLayout(null);
		
		panelPrincipal = new JPanel();
		panelPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panelPrincipal);
		panelPrincipal.setLayout(new BorderLayout(0, 0));

		panel_btn = new JPanel();
		panel_btn.setBackground(new Color(135, 206, 235));
		panelPrincipal.add(panel_btn, BorderLayout.SOUTH);
		
		btn_crearDB = new JButton("CrearDB");
		btn_crearDB.setBackground(SystemColor.controlHighlight);
		btn_crearDB.setPreferredSize(new Dimension(300, 60));
		btn_crearDB.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btn_crearDB.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		panel_btn.add(btn_crearDB);

		btn_usarDB = new JButton("UsarDB");
		btn_usarDB.setBackground(SystemColor.controlHighlight);
		btn_usarDB.setPreferredSize(new Dimension(300, 60));
		btn_usarDB.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btn_usarDB.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		panel_btn.add(btn_usarDB);

		btn_editarDB = new JButton("EditarDB");
		btn_editarDB.setBackground(SystemColor.controlHighlight);
		btn_editarDB.setPreferredSize(new Dimension(300, 60));
		btn_editarDB.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btn_editarDB.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		panel_btn.add(btn_editarDB);

		panel_central = new JPanel();
		panelPrincipal.add(panel_central, BorderLayout.CENTER);
		panel_central.setLayout(new BorderLayout(0, 0));

		panel_central.add(panelSeleccionarDB);
		panelSeleccionarDB.setVisible(true);
		panelVerDB.setVisible(false);
		panelCrearDB.setVisible(false);
		deshabilitarBotones();

		btn_usarDB.addMouseListener(new botonActionPerformed());
		btn_editarDB.addMouseListener(new botonActionPerformed());
		btn_crearDB.addMouseListener(new botonActionPerformed());
	}

	private void deshabilitarBotones() {
		if (panelSeleccionarDB.isVisible()) {
			btn_usarDB.setEnabled(false);
			btn_editarDB.setEnabled(true);
			btn_crearDB.setEnabled(true);
		}else if (panelVerDB.isVisible()) {
			btn_usarDB.setEnabled(true);
			btn_editarDB.setEnabled(false);
			btn_crearDB.setEnabled(true);
		}else if (panelCrearDB.isVisible()) {
			btn_usarDB.setEnabled(true);
			btn_editarDB.setEnabled(true);
			btn_crearDB.setEnabled(false);
		}
	}

	class botonActionPerformed extends MouseAdapter {
		public void mouseClicked(MouseEvent e) {
			Object evt = e.getSource();
			if (evt.equals(btn_usarDB)) {
				panelVerDB.setVisible(false);
				panelSeleccionarDB.setVisible(true);
				panelCrearDB.setVisible(false);
				panel_central.add(panelSeleccionarDB);
				panel_central.validate();
				deshabilitarBotones();
			}else if (evt.equals(btn_editarDB)) {
				/*Comprobar si hay una conexi�n activa.
				 * S� la hay ejecuta la acci�n.
				 * S� no la hay no la ejecuta.
				 * */
				if (panelSeleccionarDB.getConexionEstablecida()) {
					panelSeleccionarDB.setVisible(false);
					panelVerDB.setVisible(true);
					panelCrearDB.setVisible(false);
					panel_central.add(panelVerDB);
					panel_central.validate();
					deshabilitarBotones();
				}
			}else if (evt.equals(btn_crearDB)) {
				panelVerDB.setVisible(false);
				panelSeleccionarDB.setVisible(false);
				panelCrearDB.setVisible(true);
				panel_central.add(panelCrearDB);
				panel_central.validate();
				deshabilitarBotones();
			}
		}
	}

}
