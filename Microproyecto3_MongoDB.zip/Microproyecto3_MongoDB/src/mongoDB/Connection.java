package mongoDB;

import java.io.IOException;
import java.util.List;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCommandException;
import com.mongodb.client.ListIndexesIterable;
import com.mongodb.client.MongoIterable;
import com.mongodb.client.model.IndexOptions;
import com.mongodb.client.model.Indexes;
import com.mongodb.util.JSON;
import mongoDB.panel.ListInserts;

@SuppressWarnings("deprecation")
public class Connection {
	
	private BasicDBObject document = new BasicDBObject();
	private MongoClient mongo;
	private StringBuffer buffer = new StringBuffer();

	public Connection() {
		mongo = new MongoClient("localhost", 27017);
	}
	
	//Getters y Setters
	
	//Me guardo la conexi�n
	public MongoClient getMongo() {
		return mongo;
	}
	
	//Getter del buffer
	public StringBuffer getBuffer() {
		return buffer;
	}
	
	//M�todo para vaciarme el buffer
	public void cleanBuffer() {
		this.buffer.setLength(0);
	}
	
	//Obtener Base de Datos
	public List <String> getDBs() {
		return getMongo().getDatabaseNames();
	}
	
	//Obtener Colecciones de la Base de Datos
	public MongoIterable<String> getCollections(String db){
		return getMongo().getDatabase(db).listCollectionNames();
	}
	
	//Contar las colecciones del documento
	public long contarDocumentos(String db, String collection) {
		return getMongo().getDatabase(db).getCollection(collection).countDocuments();
	}
	
	//M�todo que muestra los Indices
	public ListIndexesIterable<Document> mostrarIndices(String db, String coleccion) {
		return getMongo().getDatabase(db).getCollection(coleccion).listIndexes();
	}
	
	//Creaci�n de Base de Datos
	public void crearBaseDatos(String db, String coleccion) {
		getMongo().getDatabase(db).createCollection(coleccion);
	}
	
	//Creaci�n de un Indice Ascendente
	public void crearIndicesAcendentes(String db, String coleccion, String index) {
		getMongo().getDatabase(db).getCollection(coleccion).createIndex(Indexes.ascending(index));
	}
	
	//Creaci�n de un Indice Descendente
	public void crearIndicesDescendentes(String db, String coleccion, String index) {
		getMongo().getDatabase(db).getCollection(coleccion).createIndex(Indexes.descending(index));
	}
	
	//Creaci�n de un Indice Descendente
	public boolean eliminarIndice(String db, String coleccion, String index) {
		try {
			getMongo().getDatabase(db).getCollection(coleccion).dropIndex(index);
			return true;
		}catch (MongoCommandException e) {
			return false;
		}
	}
	
	//Eliminar la Base de Datos
	public boolean eliminarBaseDatos(String db) {
		if (contieneDB(db)) {
			getMongo().getDatabase(db).drop();
			return true;
		}else {
			return false;
		}
	}
	
	//Eliminar la Colecci�n
	public boolean eliminarCollection(String db, String coleccion) {
		if (contieneCollection(db, coleccion)) {
			getMongo().getDatabase(db).getCollection(coleccion).drop();
			return true;
		}else {
			return false;
		}
	}
	
	//Comprobar si exite la base de datos
	private boolean contieneDB(String db) {
		List <String> baseDatos = getDBs();
		for (String dbs : baseDatos) {
			if (dbs.toString().equals(db)) {
				return true;
			}
		}
		return false;
	}
	
	//Comprobar si existe la colecci�n
	private boolean contieneCollection(String db, String collection) {
		MongoIterable<String> iterable = getCollections(db);
		for (String coll : iterable) {
			if (coll.toString().equals(collection)) {
				return true;
			}
		}
		return false;
	}
	
	//Insertar contenido dentro de la colecci�n
	public void insertar(DB db, String coleccion, List<ListInserts> list) {
		DBCollection colec = db.getCollection(coleccion);
		
		for (ListInserts insertarString : list) {
			//Insertar Strings
			if (insertarString.getValueString() != null) {
				document.put(insertarString.getKey(), insertarString.getValueString());
			//Insertar Date
			}else if (insertarString.getValueDate() != null) {
				document.put(insertarString.getKey(), insertarString.getValueDate());
			}else if (insertarString.getValueInt() != 0) {
				document.put(insertarString.getKey(), insertarString.getValueInt());
			}else if (insertarString.isTrue()) {
				document.put(insertarString.getKey(), insertarString.getValueBoolean());
			}else if (insertarString.getValueArr() != null) {
				document.put(insertarString.getKey(), insertarString.getValueArr());
			}else if (insertarString.getValueMap() != null) {
				document.put(insertarString.getKey(), insertarString.getValueMap());
			}
			
		}
		colec.insert(document);
		document.clear();
	}
	
	//Insertar mediante un JSON
	public void insertarJSON(DB db, String coleccion, String json) throws IOException {
		DBCollection colec = db.getCollection(coleccion);
		colec.insert((DBObject) JSON.parse(json));
	}
	
	//Mostrar los documentos de la colecci�n
	public void mostrar(DB db, String coleccion) {
		DBCollection colec = db.getCollection(coleccion);
		DBCursor cursor = colec.find();
		try {
			while (cursor.hasNext()) {
				buffer.append(cursor.next()+ "\n\n");
			}
		} finally {
		  cursor.close(); 
		}
	}
	
	//Encontrar un documento que en concreto contenga la Clave y el Valor
	public void encontrar(DB db, String coleccion, String key, String value) {
		DBCollection colec = db.getCollection(coleccion);
		BasicDBObject query = new BasicDBObject(key, value);
		DBCursor cursor = colec.find(query);
		try {
			while (cursor.hasNext()) {
				buffer.append(cursor.next() + "\n\n");
			}
		} finally {
		  cursor.close(); 
		}
	}
	
	//Actualizar el contenido de la colecci�n
	public void actualizar(DB db, String coleccion, int num, String resultado) {
		DBCollection colec = db.getCollection(coleccion);
		DBCursor cursor = colec.find();
		int iteration = 0;
		try {
			while (cursor.hasNext()) {
				if (iteration==num) {
					colec.update(cursor.next(), (DBObject) JSON.parse(resultado));
					break;
				}
				else {
					iteration ++;
					cursor.next();
				}
			}
		} finally {
			cursor.close(); 
		}
	}
	
	//Eliminar el contenido de la colecci�n
	public void eliminar(DB db, String coleccion, int num) {
		DBCollection colec = db.getCollection(coleccion);
		DBCursor cursor = colec.find();
		int iteration = 0;
		try {
			while (cursor.hasNext()) {
				if (iteration==num) {
					colec.remove(cursor.next());
					break;
				}
				else {
					iteration ++;
					cursor.next();
				}
			}
		} finally {
			cursor.close(); 
		}
		
	}
	
}

/*
//Actualizar el contenido de la colecci�n
public boolean actualizar(DB db, String coleccion, String tituloViejo, String accionVieja, String tituloNuevo, String accionNueva) {
	DBCollection colec = db.getCollection(coleccion);
	if (contieneColeccion(db, coleccion, tituloViejo)) {
		//Sentencia con la informaci�n a remplazar
		BasicDBObject vieja = new BasicDBObject();
		vieja.append(tituloViejo, accionVieja);
		
		//Busca el documento en la coleccion
		BasicDBObject nueva = new BasicDBObject();
		nueva.append(tituloNuevo, accionNueva);
		
		//Realizar la actualizaci�n
		//colec.update(buscar, actualizar);
		//colec.updateMulti(buscar, actualizar);
		colec.update(vieja, nueva, false, false);
		return true;
	}else {
		return false;
	}
}

public boolean actualizarDate(DB db, String coleccion, String titulo, Date dateViejo, Date dateNuevo) {
	DBCollection colec = db.getCollection(coleccion);
	BasicDBObject query = new BasicDBObject(titulo, dateViejo);
	BasicDBObject update = new BasicDBObject("$currentDate",new BasicDBObject(titulo, dateNuevo) );
	colec.update(query,update,true,false);
	return true;
}
//Comprobar si el t�tulo lo contiene la colecci�n
private boolean contieneColeccion(DB db,String coleccion, String titulo) {
	DBCollection colec = db.getCollection(coleccion);
	DBCursor cursor = colec.find();
	try {
		while (cursor.hasNext()) {
			if (cursor.next().containsField(titulo)) {
				return true;
			}
		}
	} finally {
	  cursor.close(); 
	}
	return false;
}*/