package mongoDB;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Image;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import com.mongodb.DB;
import com.mongodb.DBCollection;

import TextPrompt.TextPrompt;
import mongoDB.panel.ListInserts;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.List;
import java.awt.event.ActionEvent;

public class PanelSeleccionarDB extends JPanel {

	private static final long serialVersionUID = 4811396013931021605L;
	
	//Conexion
	private Connection conexion = new Connection();
	private static DB baseDatos;
	private static String collection;
	private static boolean conexionEstablecida = false;
	
	//Interfaz gr�fica
	private final ImageIcon tick = new ImageIcon("src\\Imagenes\\tick.png");
	private final ImageIcon x = new ImageIcon("src\\Imagenes\\x.png");
	
	private final JButton btn_usar;
	
	private final JPanel panel;
	private final JPanel panel_1;
	private final JPanel panel_2;
	private final JPanel panel_3;
	private final JPanel panel_4;
	
	private final JLabel level1;
	private final JLabel level2;
	private final JLabel level4;
	private final JLabel level5;
	
	private final JTextField text_DB;
	private final JTextField text_CL;
	
	private TextPrompt placeholder;
	
	public PanelSeleccionarDB() {

		setLayout(new BorderLayout(0, 0));
		setSize(1013, 618);

		panel = new JPanel();
		add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));

		level2 = new JLabel();
		level2.setPreferredSize(new Dimension(0, 50));
		panel.add(level2, BorderLayout.SOUTH);

		panel_4 = new JPanel();
		panel_4.setPreferredSize(new Dimension(200, 0));
		panel.add(panel_4, BorderLayout.WEST);
		panel_4.setLayout(new BorderLayout(0, 0));

		level4 = new JLabel();
		level4.setPreferredSize(new Dimension(0, 50));
		panel.add(level4, BorderLayout.NORTH);

		level5 = new JLabel();
		level5.setPreferredSize(new Dimension(200, 0));
		panel.add(level5, BorderLayout.EAST);

		panel_3 = new JPanel();
		panel.add(panel_3, BorderLayout.CENTER);
		panel_3.setLayout(new BorderLayout(0, 0));

		text_DB = new JTextField();
		text_DB.setPreferredSize(new Dimension(0, 50));
		text_DB.setFont(new Font("Arial", text_DB.getFont().getStyle() & ~Font.ITALIC | Font.BOLD,
				text_DB.getFont().getSize() + 15));
		text_DB.setHorizontalAlignment(SwingConstants.CENTER);
		panel_3.add(text_DB, BorderLayout.NORTH);
		placeholder = new TextPrompt("Base de Datos", text_DB);
		placeholder.setHorizontalAlignment(SwingConstants.CENTER);

		text_CL = new JTextField();
		text_CL.setPreferredSize(new Dimension(0, 50));
		text_CL.setFont(new Font("Arial", text_CL.getFont().getStyle() & ~Font.ITALIC | Font.BOLD,
				text_CL.getFont().getSize() + 15));
		text_CL.setHorizontalAlignment(SwingConstants.CENTER);
		panel_3.add(text_CL, BorderLayout.SOUTH);
		placeholder = new TextPrompt("Colecci�n", text_CL);
		placeholder.setHorizontalAlignment(SwingConstants.CENTER);

		level1 = new JLabel("�Qu� base de datos desea usar?");
		level1.setForeground(new Color(25, 25, 112));
		level1.setFont(new Font("Arial", level1.getFont().getStyle() & ~Font.ITALIC | Font.BOLD,
				level1.getFont().getSize() + 20));
		level1.setPreferredSize(new Dimension(0, 130));
		level1.setHorizontalAlignment(SwingConstants.CENTER);
		add(level1, BorderLayout.NORTH);

		panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(0, 150));
		panel_1.setLayout(new BorderLayout(0, 0));
		add(panel_1, BorderLayout.SOUTH);

		panel_2 = new JPanel();
		panel_2.setPreferredSize(new Dimension(0, 90));
		panel_1.add(panel_2, BorderLayout.NORTH);
		panel_2.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		btn_usar = new JButton("Usar");
		btn_usar.setBackground(new Color(64, 224, 208));
		btn_usar.setFont(new Font("Arial Narrow", btn_usar.getFont().getStyle() & ~Font.ITALIC | Font.BOLD,
				btn_usar.getFont().getSize() + 7));
		btn_usar.setPreferredSize(new Dimension(150, 70));
		panel_2.add(btn_usar);

		actionPerformedBtn(btn_usar);
		detectarEscritura(text_DB);
		detectarEscritura(text_CL);
	}
	
	//Guardarme la Base de Datos y la Colecci�n que voy a utilizar
	private void actionPerformedBtn(JButton btn) {
		btn.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent e) {
				collection = text_CL.getText();
				baseDatos = conexion.getMongo().getDB(text_DB.getText());
				
				if (baseDatos.collectionExists(text_CL.getText())) {
					level5.setIcon(new ImageIcon(tick.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
					conexionEstablecida = true;
				} else {
					level5.setIcon(new ImageIcon(x.getImage().getScaledInstance(90, 60, Image.SCALE_DEFAULT)));
					conexionEstablecida = false;
				}

			}
		});
	}
	
	//M�todo que utilizo en la clase principal para detectar si hay una conexi�n activa
	public boolean getConexionEstablecida() {
		return conexionEstablecida;
	}
	
	//Insertar Normal garantiza que funcione
	public void insertar(List<ListInserts> list) {
		conexion.insertar(baseDatos, collection, list);
	}
	
	//Insertar JSON no garantiza que funcione
	public void insertarJSON(String json) throws IOException {
		conexion.insertarJSON(baseDatos, collection, json);
	}
	
	//Mostrar todos los documentos de la colecci�n
	public Connection mostrar() {
		conexion.mostrar(baseDatos, collection);
		return conexion;
	}
	
	//Encontrar el documento
	public Connection encontrar(String key, String value) {
		conexion.encontrar(baseDatos, collection, key, value);
		return conexion;
	}
	
	//Actualizar la Base de Datos
	public void actualizar (int num, String resultado) {
		conexion.actualizar(baseDatos, collection, num, resultado);
	}
	
	//Eliminar documento en la collection
	public void eliminar(int num) {
		conexion.eliminar(baseDatos, collection, num);
	}
	
	//Obtener la colecci�n
	public DBCollection getCollection() {
		return baseDatos.getCollection(collection);
	}
	
	//Detecta la escritura para poner borrar el icono de la imagen
	private void detectarEscritura(JTextField text) {
		text.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if (!Character.isDigit(c) || Character.isDigit(c)) {
					level5.setIcon(null);
				}
			}
		});
	}

}
